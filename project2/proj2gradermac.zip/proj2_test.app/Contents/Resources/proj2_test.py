from proj2_core import *

def main():
    print("UB CSE 4/560 Project 2 Grader (Version %s)" % VERSION)
    if DEBUG:
        print("Working directory: %s" % os.getcwd())

    if read_config() == None:
        print("Cannot read config file.")
        sys.exit(1)
    elif not test_connect():
        sys.exit(2)

    run_core()

main()